import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  FiStar, FiHeart, FiArrowRight,
  FiShield, FiTruck, FiZap, FiTag, FiShoppingCart
} from "react-icons/fi";
import Navbar from "../components/Navbar";

const PRODUCTS = [
  {
    id: 1, name: "iPhone 15 Pro", sub: "Titanium. So strong. So light.",
    price: "₹1,29,999", old: "₹1,39,999", rating: 4.9, reviews: 2841,
    badge: "Best Seller", badgeBg: "rgba(245,158,11,.15)", badgeColor: "#f59e0b",
    img: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80",
  },
  {
    id: 2, name: "MacBook Air M3", sub: "Supercharged by M3.",
    price: "₹1,49,999", old: "₹1,69,999", rating: 4.8, reviews: 1923,
    badge: "New Arrival", badgeBg: "rgba(34,197,94,.15)", badgeColor: "#22c55e",
    img: "https://images.unsplash.com/photo-1517336714739-489689fd1ca8?w=400&q=80",
  },
  {
    id: 3, name: "AirPods Pro", sub: "Adaptive Audio. Now playing.",
    price: "₹24,999", old: "₹29,999", rating: 4.7, reviews: 4102,
    badge: "Hot Deal", badgeBg: "rgba(239,68,68,.15)", badgeColor: "#ef4444",
    img: "https://images.unsplash.com/photo-1588423771073-b8903fbb85b5?w=400&q=80",
  },
];

const CATS = [
  { label: "Phones",      emoji: "📱", bg: "rgba(99,102,241,.12)"  },
  { label: "Laptops",     emoji: "💻", bg: "rgba(139,92,246,.12)"  },
  { label: "Audio",       emoji: "🎧", bg: "rgba(236,72,153,.12)"  },
  { label: "Tablets",     emoji: "📲", bg: "rgba(34,197,94,.12)"   },
  { label: "Wearables",   emoji: "⌚", bg: "rgba(245,158,11,.12)"  },
  { label: "Accessories", emoji: "🔌", bg: "rgba(6,182,212,.12)"   },
];

const FEATURES = [
  { icon: <FiTruck />,  color: "#6366f1", bg: "rgba(99,102,241,.12)", title: "Free Delivery",     desc: "On orders above ₹999" },
  { icon: <FiShield />, color: "#22c55e", bg: "rgba(34,197,94,.12)",  title: "2-Year Warranty",   desc: "On all products" },
  { icon: <FiZap />,    color: "#f59e0b", bg: "rgba(245,158,11,.12)", title: "Same Day Dispatch", desc: "Order before 2 PM" },
  { icon: <FiTag />,    color: "#ec4899", bg: "rgba(236,72,153,.12)", title: "Best Price",        desc: "Price match guarantee" },
];

const STATS = [["50K+", "Customers"], ["10K+", "Products"], ["4.9★", "Rating"], ["₹500", "Bonus"]];

const fu = (d = 0) => ({
  initial: { opacity: 0, y: 18 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94], delay: d },
});

/* ── Divider between sections ── */
const Divider = () => (
  <div className="max-w-7xl mx-auto px-8">
    <div style={{ height: "1px", background: "rgba(255,255,255,0.05)" }} />
  </div>
);

/* ── Section header ── */
function SectionHeader({ label, title, linkText, onLink }) {
  return (
    <div className="flex justify-between items-end mb-7">
      <div>
        <p className="text-[10px] font-bold text-zinc-600 uppercase tracking-[0.12em] mb-1.5">{label}</p>
        <h2 className="text-xl font-bold text-white leading-tight">{title}</h2>
      </div>
      {linkText && (
        <button
          onClick={onLink}
          className="flex items-center gap-1.5 text-indigo-400 text-xs font-semibold hover:text-indigo-300 transition-colors"
        >
          {linkText} <FiArrowRight className="text-[10px]" />
        </button>
      )}
    </div>
  );
}

export default function Home() {
  const navigate = useNavigate();
  const [cart, setCart]   = useState([]);
  const [liked, setLiked] = useState({});

  return (
    <div style={{ background: "#09090b", minHeight: "100vh" }}>
      <Navbar cartCount={cart.length} />

      {/* ══════════════════════════════════════
          HERO
      ══════════════════════════════════════ */}
      <section
        className="relative overflow-hidden"
        style={{ paddingTop: "60px" }}
      >
        {/* Ambient orbs — kept well outside content area */}
        <div className="orb" style={{ width: 480, height: 480, top: -160, left: -160, background: "rgba(99,102,241,.13)" }} />
        <div className="orb" style={{ width: 380, height: 380, top: -100, right: -140, background: "rgba(139,92,246,.09)" }} />

        {/* Subtle grid */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage: "linear-gradient(rgba(255,255,255,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.04) 1px,transparent 1px)",
            backgroundSize: "48px 48px",
          }}
        />

        <div className="max-w-7xl mx-auto px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-10 items-center py-16 pb-20">

            {/* ── Left: Copy ── */}
            <motion.div {...fu()}>
              {/* Pill badge */}
              <div
                className="inline-flex items-center gap-2 badge mb-6"
                style={{ background: "rgba(99,102,241,.1)", color: "#818cf8", border: "1px solid rgba(99,102,241,.2)" }}
              >
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                India's #1 Premium Electronics Store
              </div>

              {/* Headline */}
              <h1
                className="font-bold text-white leading-[1.07] tracking-tight"
                style={{ fontSize: "clamp(2.4rem, 5vw, 3.5rem)" }}
              >
                Shop the<br />
                <span className="grad-text">Future</span><br />
                Today.
              </h1>

              {/* Sub-copy */}
              <p className="text-zinc-500 text-sm mt-5 leading-7 max-w-[400px]">
                Discover premium electronics, next-gen gadgets and luxury tech —
                curated for those who demand the best.
              </p>

              {/* CTA buttons */}
              <div className="flex items-center gap-3 mt-7">
                <motion.button
                  whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                  onClick={() => navigate("/products")}
                  className="btn btn-primary px-6 py-2.5 text-sm rounded-xl"
                >
                  Shop Now <FiArrowRight />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                  onClick={() => navigate("/products")}
                  className="btn btn-outline px-6 py-2.5 text-sm rounded-xl"
                >
                  Explore All
                </motion.button>
              </div>

              {/* Stats row */}
              <div
                className="flex items-center gap-7 mt-8 pt-7"
                style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
              >
                {STATS.map(([v, l]) => (
                  <div key={l}>
                    <p className="text-base font-bold text-white">{v}</p>
                    <p className="text-zinc-600 text-[11px] mt-0.5">{l}</p>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* ── Right: Product showcase ── */}
            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.85, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="flex justify-center items-center"
              style={{ paddingTop: "24px", paddingBottom: "24px" }}
            >
              {/* Glow behind image */}
              <div
                className="orb"
                style={{ width: 260, height: 260, top: "50%", left: "50%", transform: "translate(-50%,-50%)", background: "rgba(99,102,241,.14)" }}
              />

              {/* Outer wrapper — gives space for floating badges */}
              <div className="relative" style={{ width: 300, height: 300 }}>

                {/* Product frame — centred inside wrapper */}
                <div
                  className="absolute float"
                  style={{
                    top: "50%", left: "50%",
                    transform: "translate(-50%,-50%)",
                    width: 220, height: 220,
                    borderRadius: 28,
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.07)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                  }}
                >
                  <img
                    src="https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80"
                    style={{ width: 160, height: 160, objectFit: "contain" }}
                    className="drop-shadow-2xl"
                    alt="iPhone 15 Pro"
                  />
                </div>

                {/* Badge: Top Rated — top-right corner of wrapper */}
                <motion.div
                  initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.9 }}
                  className="absolute glass rounded-xl px-3 py-2 float2"
                  style={{ top: 0, right: 0 }}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: "rgba(245,158,11,.15)" }}>
                      <FiStar className="text-amber-400" style={{ fontSize: 10 }} />
                    </div>
                    <div>
                      <p className="text-white font-semibold leading-tight" style={{ fontSize: 11 }}>Top Rated</p>
                      <p className="text-zinc-600" style={{ fontSize: 10 }}>4.9 / 5.0</p>
                    </div>
                  </div>
                </motion.div>

                {/* Badge: Free Delivery — bottom-left corner of wrapper */}
                <motion.div
                  initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1.1 }}
                  className="absolute glass rounded-xl px-3 py-2 float"
                  style={{ bottom: 0, left: 0 }}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: "rgba(34,197,94,.15)" }}>
                      <FiTruck className="text-emerald-400" style={{ fontSize: 10 }} />
                    </div>
                    <div>
                      <p className="text-white font-semibold leading-tight" style={{ fontSize: 11 }}>Free Delivery</p>
                      <p className="text-zinc-600" style={{ fontSize: 10 }}>Above ₹999</p>
                    </div>
                  </div>
                </motion.div>

                {/* Badge: Orders — bottom-right corner */}
                <motion.div
                  initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.3 }}
                  className="absolute glass rounded-xl px-3 py-2"
                  style={{ bottom: 0, right: 0 }}
                >
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-1">
                      {["🧑", "👩", "👨"].map((e, i) => (
                        <div key={i}
                          className="w-5 h-5 rounded-full flex items-center justify-center border"
                          style={{ fontSize: 9, background: "linear-gradient(135deg,#6366f1,#8b5cf6)", borderColor: "#09090b" }}>
                          {e}
                        </div>
                      ))}
                    </div>
                    <p className="text-white font-semibold" style={{ fontSize: 11 }}>1,284 today</p>
                  </div>
                </motion.div>

              </div>
            </motion.div>

          </div>
        </div>
      </section>

      <Divider />

      {/* ══════════════════════════════════════
          FEATURES STRIP
      ══════════════════════════════════════ */}
      <section className="py-10 px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-3">
          {FEATURES.map((f, i) => (
            <motion.div key={i} {...fu(i * 0.07)} className="card p-4 flex items-center gap-3.5">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: f.bg }}
              >
                <span style={{ color: f.color, fontSize: 14 }}>{f.icon}</span>
              </div>
              <div>
                <p className="text-sm font-semibold text-white leading-tight">{f.title}</p>
                <p className="text-zinc-600 mt-0.5" style={{ fontSize: 11 }}>{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <Divider />

      {/* ══════════════════════════════════════
          CATEGORIES
      ══════════════════════════════════════ */}
      <section className="py-10 px-8">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            label="Browse"
            title="Shop by Category"
            linkText="See all"
            onLink={() => navigate("/products")}
          />
          <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
            {CATS.map((c, i) => (
              <motion.button
                key={c.label}
                {...fu(i * 0.05)}
                whileHover={{ scale: 1.04, y: -3 }}
                onClick={() => navigate("/products")}
                className="card p-4 flex flex-col items-center gap-2 cursor-pointer group"
              >
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center text-lg group-hover:scale-110 transition-transform"
                  style={{ background: c.bg }}
                >
                  {c.emoji}
                </div>
                <p className="text-zinc-400 font-semibold" style={{ fontSize: 11 }}>{c.label}</p>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      <Divider />

      {/* ══════════════════════════════════════
          FEATURED PRODUCTS
      ══════════════════════════════════════ */}
      <section className="py-10 px-8">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            label="Handpicked"
            title="Featured Products"
            linkText="View all"
            onLink={() => navigate("/products")}
          />

          <div className="grid md:grid-cols-3 gap-4">
            {PRODUCTS.map((p, i) => (
              <motion.div
                key={p.id}
                {...fu(i * 0.1)}
                className="card-glow overflow-hidden group flex flex-col"
              >
                {/* Image area — fixed height */}
                <div
                  className="relative flex items-center justify-center flex-shrink-0"
                  style={{
                    height: 180,
                    background: "rgba(255,255,255,0.02)",
                    borderBottom: "1px solid rgba(255,255,255,0.05)",
                  }}
                >
                  <img
                    src={p.img}
                    className="object-contain group-hover:scale-105 transition duration-500 drop-shadow-2xl"
                    style={{ height: 120, width: "auto" }}
                    alt={p.name}
                  />
                  <span
                    className="absolute top-3 left-3 badge"
                    style={{ background: p.badgeBg, color: p.badgeColor }}
                  >
                    {p.badge}
                  </span>
                  <button
                    onClick={() => setLiked(prev => ({ ...prev, [p.id]: !prev[p.id] }))}
                    className="absolute top-3 right-3 w-7 h-7 glass rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                  >
                    <FiHeart
                      style={{ fontSize: 11, ...(liked[p.id] ? { color: "#f87171", fill: "#f87171" } : { color: "#52525b" }) }}
                    />
                  </button>
                </div>

                {/* Info — flex-1 so all cards same height */}
                <div className="p-4 flex flex-col flex-1">
                  <div className="flex items-center gap-1.5 mb-2">
                    <FiStar className="text-amber-400" style={{ fontSize: 10 }} />
                    <span className="text-zinc-500" style={{ fontSize: 11 }}>
                      {p.rating} ({p.reviews.toLocaleString()} reviews)
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white leading-tight">{p.name}</h3>
                  <p className="text-zinc-600 mt-1" style={{ fontSize: 11 }}>{p.sub}</p>

                  {/* Price + button pushed to bottom */}
                  <div className="mt-auto pt-4 flex items-center justify-between">
                    <div>
                      <span className="text-sm font-bold text-white">{p.price}</span>
                      <span className="text-zinc-600 line-through ml-2" style={{ fontSize: 11 }}>{p.old}</span>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.95 }}
                      onClick={() => setCart(prev => [...prev, p])}
                      className="btn btn-primary px-3.5 py-2 text-xs rounded-xl"
                    >
                      <FiShoppingCart style={{ fontSize: 11 }} /> Add
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Divider />

      {/* ══════════════════════════════════════
          CTA BANNER
      ══════════════════════════════════════ */}
      <section className="py-10 px-8 pb-20">
        <div className="max-w-7xl mx-auto">
          <motion.div
            {...fu()}
            className="relative overflow-hidden rounded-2xl noise"
            style={{
              background: "linear-gradient(135deg,#1e1b4b 0%,#312e81 55%,#4c1d95 100%)",
              border: "1px solid rgba(99,102,241,.22)",
            }}
          >
            {/* Orbs inside banner */}
            <div className="orb" style={{ width: 220, height: 220, top: -60, right: -40, background: "rgba(139,92,246,.28)" }} />
            <div className="orb" style={{ width: 160, height: 160, bottom: -50, left: "38%", background: "rgba(236,72,153,.18)" }} />

            <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6 px-10 py-9">
              <div className="text-white">
                <span
                  className="badge mb-4"
                  style={{ background: "rgba(255,255,255,.1)", color: "rgba(255,255,255,.6)", border: "1px solid rgba(255,255,255,.1)" }}
                >
                  🔥 Limited Time Offer
                </span>
                <h2 className="text-2xl font-bold leading-snug">
                  Get <span className="text-amber-300">20% OFF</span> your first order
                </h2>
                <p className="text-white/50 mt-2 text-sm">
                  Use code{" "}
                  <span
                    className="font-bold text-white px-2 py-0.5 rounded-lg"
                    style={{ background: "rgba(255,255,255,.1)", border: "1px solid rgba(255,255,255,.12)" }}
                  >
                    SMART20
                  </span>
                  {" "}at checkout
                </p>
              </div>

              <motion.button
                whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                onClick={() => navigate("/products")}
                className="btn flex-shrink-0 flex items-center gap-2 px-7 py-3 text-sm rounded-xl font-bold"
                style={{ background: "#fff", color: "#312e81" }}
              >
                Explore Store <FiArrowRight />
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>

    </div>
  );
}
